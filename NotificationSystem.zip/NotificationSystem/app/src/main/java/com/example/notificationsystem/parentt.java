package com.example.notificationsystem;

public class parentt {
    String sname;
    String pname;
    String pctno;
    String sclass;
    String srollno;

    public parentt() {
    }

    public parentt(String sname, String pname, String pctno, String sclass, String srollno) {
        this.sname = sname;
        this.pname = pname;
        this.pctno = pctno;
        this.sclass = sclass;
        this.srollno = srollno;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getPctno() {
        return pctno;
    }

    public void setPctno(String pctno) {
        this.pctno = pctno;
    }

    public String getSclass() {
        return sclass;
    }

    public void setSclass(String sclass) {
        this.sclass = sclass;
    }

    public String getSrollno() {
        return srollno;
    }

    public void setSrollno(String srollno) {
        this.srollno = srollno;
    }
}
