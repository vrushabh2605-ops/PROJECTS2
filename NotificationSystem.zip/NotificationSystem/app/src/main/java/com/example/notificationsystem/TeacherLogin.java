package com.example.notificationsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.notificationsystem.R;

public class TeacherLogin extends AppCompatActivity {
    EditText username ,password;
    Button reg ,login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_login);
        username=findViewById(R.id.editText13);
        password=findViewById(R.id.editText14);
        password.setTransformationMethod( new AsteriskPasswordTransformationMethod());
        login=findViewById(R.id.button14);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(username.getText().toString().equals("teacher") && password.getText().toString().equals("teacher")){
                    Toast.makeText(getApplicationContext(),"Login Successfully..",Toast.LENGTH_SHORT).show();
                    //correcct password
                    Intent it=new Intent(TeacherLogin.this,TeacherHome.class);
                    startActivity(it);
                }else{
                    Toast.makeText(getApplicationContext(),"Login Unsuccessfully..",Toast.LENGTH_SHORT).show();
                    //wrong password
                    Intent it=new Intent(TeacherLogin.this,TeacherLogin.class);
                    startActivity(it);
                }


                String semail=username.getText().toString();
                String spass=password.getText().toString();
               
                username.setText(" ");
                password.setText(" ");

            }
        });

    }
}
