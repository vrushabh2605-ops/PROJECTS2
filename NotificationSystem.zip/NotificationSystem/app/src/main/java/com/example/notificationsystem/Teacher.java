package com.example.notificationsystem;

public class Teacher {
    String tid;
    String tname;
    String tcontact;
    String tqual;

    public Teacher() {
    }

    public Teacher(String tid, String tname, String tcontact, String tqual) {
        this.tid = tid;
        this.tname = tname;
        this.tcontact = tcontact;
        this.tqual = tqual;
    }

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String getTname() {
        return tname;
    }

    public void setTname(String tname) {
        this.tname = tname;
    }

    public String getTcontact() {
        return tcontact;
    }

    public void setTcontact(String tcontact) {
        this.tcontact = tcontact;
    }

    public String getTqual() {
        return tqual;
    }

    public void setTqual(String tqual) {
        this.tqual = tqual;
    }
}
