package com.example.notificationsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class StudentsList extends AppCompatActivity {
    ListView lv;
    DatabaseReference myRef;
    ArrayAdapter<String> aad;
    ArrayList<String>al;
    FirebaseDatabase database;
    String s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_students_list);
        lv=findViewById(R.id.list);

        Intent it=getIntent();
        s= it.getStringExtra("classkey");

        al = new ArrayList<String>();

        aad = new ArrayAdapter<String>(
                getApplicationContext()
                ,android.R.layout.simple_list_item_1
                ,al
        );
        lv.setAdapter(aad);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("parentstd");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                al = new ArrayList<String>();
//
                for(DataSnapshot i:dataSnapshot.getChildren())
                {
                    parentt p=i.getValue(parentt.class);

                    if(p.getSclass().equalsIgnoreCase(s)){
                        String data=new StringBuffer("Parent Name : "+p.getPname())
                                .append("\n")
                                .append("Student Name: " + p.sname)
                                .append("\n")
                                .append("Class:" + p.sclass)
                                .append("\n")
                                .append("Roll No: " + p.srollno)
                                .append("\n")
                                .append("Contact No: " + p.pctno)
                                .toString();
                        al.add(data);}
                }
                aad = new ArrayAdapter<String>(
                        getApplicationContext()
                        ,android.R.layout.simple_list_item_1
                        ,al
                );
                lv.setAdapter(aad);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value

            }
        });
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String s=lv.getItemAtPosition(position).toString();
                Intent i = new Intent(StudentsList.this,SendNotification.class);
                i.putExtra("m",s);
                startActivity(i);
            }
        });
    }
}
