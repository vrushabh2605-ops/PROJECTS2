package com.example.notificationsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.TransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AdminLogin extends AppCompatActivity {
    EditText username, password;
    Button login;
    String status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
        username = findViewById(R.id.editText);
        password = findViewById(R.id.editText2);
        password.setTransformationMethod(new AsteriskPasswordTransformationMethod());

        login = findViewById(R.id.button4);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (username.getText().toString().equals("admin") && password.getText().toString().equals("admin")) {

                    Toast.makeText(getApplicationContext(), "Login Successfully..", Toast.LENGTH_SHORT).show();
                    Intent it1 = new Intent(AdminLogin.this, AdminHome.class);
                    startActivity(it1);

                } else {
                    Toast.makeText(getApplicationContext(), "Login Unsuccessfully..", Toast.LENGTH_SHORT).show();


                    Intent it1 = new Intent(AdminLogin.this, AdminLogin.class);
                    startActivity(it1);
                }

                String semail=username.getText().toString();
                String spass=password.getText().toString();

                username.setText("");
                password.setText("");
            }


        });

    }
}

