package com.example.notificationsystem;

public class Notify {
    String sms,mId;

    public Notify(String sms, String mId) {
        this.sms = sms;
        this.mId = mId;
    }

    public Notify() {
    }

    public String getSms() {
        return sms;
    }

    public void setSms(String sms) {
        this.sms = sms;
    }

    public String getmId() {
        return mId;
    }

    public void setmId(String mId) {
        this.mId = mId;
    }
}
