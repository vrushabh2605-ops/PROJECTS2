package com.example.notificationsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ParentRegister extends AppCompatActivity {
    FirebaseDatabase database;
    DatabaseReference myRef;
EditText name,parent,ssclass,rollNo,contactno;
Button add,back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_register);

        name=findViewById(R.id.editText7);

        parent=findViewById(R.id.editText8);

        contactno=findViewById(R.id.editText9);

        ssclass=findViewById(R.id.editText10);
        rollNo=findViewById(R.id.editText11);
        add=findViewById(R.id.button11);
        back=findViewById(R.id.button12);

        database= FirebaseDatabase.getInstance();
        myRef = database.getReference("parentstd");

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                if (name.getText().toString().length()==0) {
                    name.setError("Enter name");
                    name.requestFocus();
                }  if (parent.getText().toString().length()==0) {
                    parent.setError("Enter parent name");
                   parent.requestFocus();
                }
                     if(contactno.length()!=10){
                    contactno.setError("Enter contactno");
                    contactno.requestFocus();

                }
                  if (ssclass.getText().toString().length()==0) {
                    ssclass.setError("Enter class");
                    ssclass.requestFocus();

                }
                 if (rollNo.getText().toString().length()==0) {
                    rollNo.setError("Enter RollNo");
                    rollNo.requestFocus();

                }
                else
                {
                    addEntry(name,parent,contactno,ssclass,rollNo);
                    Toast.makeText(getApplicationContext(),"Parent Added Successfully",Toast.LENGTH_SHORT).show();
                    Intent itt=new Intent(ParentRegister.this,ParentRegister.class);
                    startActivity(itt);
                    finish();
                }


                String stname=name.getText().toString();
                String pname=parent.getText().toString();
                String pctno=contactno.getText().toString();
                String sclass=ssclass.getText().toString();
                String srollno=rollNo.getText().toString();

                parentt p=new parentt(stname,pname,pctno,sclass,srollno);
                myRef.child(srollno).setValue(p);

                Toast.makeText(getApplicationContext(),"Parent Added Successfully",Toast.LENGTH_SHORT).show();
                name.setText("");
                parent.setText("");
                ssclass.setText("");
                rollNo.setText("");
                contactno.setText("");

            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(ParentRegister.this,AdminHome.class);
                startActivity(i);
            }
        });
    }

    private void addEntry(EditText name, EditText parent, EditText contactno, EditText ssclass, EditText rollNo) {

    }
}
