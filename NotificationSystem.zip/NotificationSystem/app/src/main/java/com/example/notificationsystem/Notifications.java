package com.example.notificationsystem;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Notifications extends AppCompatActivity {
    ListView lvv;
    ArrayList<String> al;
    ArrayAdapter<String>aad;
    FirebaseDatabase database;
    DatabaseReference myRef;
String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);
        lvv=findViewById(R.id.list1);
        al=new ArrayList<String>();
         name=getIntent().getStringExtra("name");
        database=FirebaseDatabase.getInstance();
        myRef=database.getReference("Messege");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                al=new ArrayList<String>();

                for(DataSnapshot i:dataSnapshot.getChildren()){
                    Notify msg=i.getValue(Notify.class);
                    Toast.makeText(getApplicationContext()," "+name+" "+msg.getmId(),Toast.LENGTH_SHORT).show();

                  //  if((msg.getmId()).equals(name))
                    {
                        al.add(msg.getSms());
                    }

                }
                aad=new ArrayAdapter<String>(
                        getApplicationContext()
                        ,android.R.layout.simple_list_item_1
                        ,al
                );
                lvv.setAdapter(aad);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
       al=new ArrayList<String>();
       aad=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,al);
        lvv.setAdapter(aad);
        database= FirebaseDatabase.getInstance();
       myRef = database.getReference("parentstd");
    }
}
