package com.example.notificationsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ParentLogin extends AppCompatActivity {
EditText username,password;
Button login;
    FirebaseDatabase database;
    DatabaseReference myRef;
    String name;
    String pass;
boolean t=true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_login);
        username=findViewById(R.id.editText16);
        password=findViewById(R.id.editText17);
        password.setTransformationMethod( new AsteriskPasswordTransformationMethod());
        login=findViewById(R.id.button17);
        database= FirebaseDatabase.getInstance();
        myRef = database.getReference("parentstd");
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Read from the database
                name=username.getText().toString();
                pass=password.getText().toString();
            //    Toast.makeText(getApplicationContext(),"sdhbhj"+name+" "+pass,Toast.LENGTH_SHORT).show();


//                myRef.addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(DataSnapshot dataSnapshot) {
//                        // This method is called once with the initial value and again
//                        // whenever data at this location is updated.
//                        for(DataSnapshot i:dataSnapshot.getChildren()){
//                            Log.i(String.valueOf(i), "hello");
//                            parentt p =i.getValue(parentt.class) ;
//                          //  Toast.makeText(getApplicationContext(),""+p.getPname()+" "+p.pctno,Toast.LENGTH_SHORT).show();
//
//
//                            if(p.getPname().equals(name)&&p.getPctno().equals(pass ))
//                            {
//                                t=false;
//                                Intent it1=new Intent(ParentLogin.this,ViewNotify.class);
//                                it1.putExtra("pname",name);
//                                startActivity(it1);
//
//                                Toast.makeText(getApplicationContext(),"Login Successfully",Toast.LENGTH_SHORT).show();
//                            } else
//                            {
//                                Toast.makeText(getApplicationContext(),"Login Unsuccessful",Toast.LENGTH_SHORT).show();
//                            }
//                        }
//                    }
//
//                    @Override
//                    public void onCancelled(DatabaseError error) {
//                        // Failed to read value
//                    }
//                });

               if(username.getText().toString().equals("parent") && password.getText().toString().equals("parent")){
                    Toast.makeText(getApplicationContext(),"Login Successfully..",Toast.LENGTH_SHORT).show();

                    Intent it1=new Intent(ParentLogin.this,ViewNotify.class);
                    startActivity(it1);
                }else{
                    Toast.makeText(getApplicationContext(),"Login Unsuccessfully..",Toast.LENGTH_SHORT).show();
                    //wrong password
                    Intent it1=new Intent(ParentLogin.this,ParentLogin.class);
                    startActivity(it1);
                }

             Toast.makeText(getApplicationContext(),"Login Successfully..",Toast.LENGTH_SHORT).show();
                username.setText("");
                password.setText("");

            }
        });


    }
}
