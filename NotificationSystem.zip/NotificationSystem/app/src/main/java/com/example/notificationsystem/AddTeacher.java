package com.example.notificationsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddTeacher extends AppCompatActivity {

EditText id1,name1,contact1,quali1;
Button save,back;
    FirebaseDatabase database;
    DatabaseReference myRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_teacher);

        id1=findViewById(R.id.editText3);

        name1=findViewById(R.id.editText4);

        contact1=findViewById(R.id.editText5);

        quali1=findViewById(R.id.editText6);
        save=findViewById(R.id.button8);
        back=findViewById(R.id.button9);
        database= FirebaseDatabase.getInstance();
        myRef = database.getReference("teachers");

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


           if (id1.getText().toString().length()==0) {
                id1.setError("Enter name");
                id1.requestFocus();
            } else if (name1.getText().toString().length()==0) {
                name1.setError("Enter parent name");
                name1.requestFocus();
            }
                  else   if(contact1.length()!=10){
                contact1.setError("Enter contactno");
                contact1.requestFocus();

            }
               else   if (quali1.getText().toString().length()==0) {
                quali1.setError("Enter class");
                quali1.requestFocus();

            }
                  else
                    {
                       /* addEntry(id1,name1,contact1,quali1);
                        Intent itt=new Intent(AddTeacher.this,AddTeacher.class);
                        startActivity(itt);
                       */ // finish();


                String tid=id1.getText().toString();
              String tname=  name1.getText().toString();
              String tcont=  contact1.getText().toString();
              String tqua=  quali1.getText().toString();
                Teacher t=new Teacher(tid,tname,tcont,tqua);
                myRef.child(tid).setValue(t);
                Toast.makeText(getApplicationContext(),"Added Successfully..",Toast.LENGTH_SHORT).show();
                id1.setText("");
                name1.setText("");
                contact1.setText("");
                quali1.setText("");
            } }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent itt=new Intent(AddTeacher.this,MainActivity.class);
                startActivity(itt);
            }
        });
    }
    private void addEntry(EditText id1, EditText name1, EditText contact1, EditText quali1) {
    }
}
