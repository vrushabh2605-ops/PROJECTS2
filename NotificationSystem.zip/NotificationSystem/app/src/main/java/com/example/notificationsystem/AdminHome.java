package com.example.notificationsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AdminHome extends AppCompatActivity {
Button teacher,student,send,back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);
        teacher=findViewById(R.id.button5);
        send=findViewById(R.id.button7);
        student=findViewById(R.id.button6);
        back=findViewById(R.id.button10);
        teacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it2=new Intent(AdminHome.this,AddTeacher.class);
                startActivity(it2);
            }
        });
        student.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it6=new Intent(AdminHome.this,ParentRegister.class);
                startActivity(it6);
            }
        });
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it3=new Intent(AdminHome.this,TeacherNotification.class);
                startActivity(it3);
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it5=new Intent(AdminHome.this,MainActivity.class);
                startActivity(it5);
            }
        });

    }
}
