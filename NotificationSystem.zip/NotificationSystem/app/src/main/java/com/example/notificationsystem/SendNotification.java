package com.example.notificationsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SendNotification extends AppCompatActivity {
EditText notification,mid;
Button send;
String mob,Mid,Messege;
    FirebaseDatabase database;
    DatabaseReference myRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_notification);
        notification=findViewById(R.id.editText12);
        mid=findViewById(R.id.editText23);
        send=findViewById(R.id.button13);
        Intent it=getIntent();
        String n=it.getStringExtra("m");
        int l=n.length();
         mob=n.substring(l-10,l);
        Toast.makeText(getApplicationContext(),mob,Toast.LENGTH_SHORT).show();
       send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
Messege=notification.getText().toString();
Mid=mid.getText().toString();
database=FirebaseDatabase.getInstance();
myRef=database.getReference("Messege");
Notify d=new Notify(Messege,Mid);
myRef.child(Mid).setValue(d);
/*

                SmsManager sms= SmsManager.getDefault();
                sms.sendTextMessage(mob,"null",ttxt,null,null);
*/
              Toast.makeText(getApplicationContext(),mob,Toast.LENGTH_SHORT).show();

            }
        });


    }
}
