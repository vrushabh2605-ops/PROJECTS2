package com.example.notificationsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ViewNotify extends AppCompatActivity {
Button view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_notify);
        view=findViewById(R.id.button18);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i8=new Intent(ViewNotify.this,Notifications.class);
                i8.putExtra("name",getIntent().getStringExtra("pname"));
                startActivity(i8);
            }
        });
    }
}
